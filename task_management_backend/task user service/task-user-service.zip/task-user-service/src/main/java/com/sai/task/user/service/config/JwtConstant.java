package com.sai.task.user.service.config;

public class JwtConstant {
    public static final String SECRET_KEY="jshngkjrhnsfkjghnsfkfghjskdjngkjrhsdilkjhwneshgoirsdjhfgnoisdfhjgikdsjzhfgniksjhdfgiksjhdfgsikdhjfdjhg";
    public static final String JWT_HEADER="Authorization";
}
